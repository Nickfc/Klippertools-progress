import Component from 'vue-class-component'
import BaseMixin from '@/components/mixins/base'
import { capitalize } from '@/plugins/helpers'
import { GuiMacrosStateMacrogroup } from '@/store/gui/macros/types'
import {
    mdiArrowCollapseVertical,
    mdiCodeTags,
    mdiConsoleLine,
    mdiDipSwitch,
    mdiEngine,
    mdiGamepad,
    mdiInformation,
    mdiGrid,
    mdiLedStrip,
    mdiPrinter3dNozzle,
    mdiProgressClock,
    mdiShieldCheckOutline,
    mdiThermometerLines,
    mdiTuneVariant,
    mdiWebcam,
    mdiWrenchClock,
    mdiAdjust,
    mdiMulticast,
    mdiToolboxOutline,
} from '@mdi/js'
import { afcIconLogo } from '@/plugins/afcIcons'

@Component
export default class DashboardMixin extends BaseMixin {
    get macrogroups() {
        return this.$store.getters['gui/macros/getAllMacrogroups'] ?? []
    }

    get webcams() {
        return this.$store.getters['gui/webcams/getWebcams'] ?? []
    }

    getPanelName(name: string) {
        if (name.startsWith('macrogroup_')) {
            const groupId = name.split('_')[1] ?? ''
            const group = this.macrogroups.find((group: GuiMacrosStateMacrogroup) => group.id === groupId)

            return group ? group.name : 'Macrogroup'
        }

        const klippertoolsLabels: Record<string, string> = {
            'nozzle-guard': 'Guard',
            'start-flow': 'Start',
            'maintenance-tracker': 'Maintenance',
            'thermal-soak': 'Thermal',
            'motion-wizard': 'Motion',
        }
        if (name in klippertoolsLabels) {
            return this.$t(`Panels.KlippertoolsPanel.Tabs.${klippertoolsLabels[name]}`)
        }

        if (name.includes('-')) {
            let panelName = ''
            const subStrings = name.split('-')
            subStrings.forEach((subStr) => {
                panelName += capitalize(subStr)
            })
            return this.$t(`Panels.${panelName}Panel.Headline`)
        }

        return this.$t(`Panels.${capitalize(name)}Panel.Headline`)
    }

    convertPanelnameToIcon(name: string): string {
        if (name.startsWith('macrogroup_')) return mdiCodeTags

        switch (name) {
            case 'webcam':
                return mdiWebcam
            case 'zoffset':
                return mdiArrowCollapseVertical
            case 'toolhead-control':
                return mdiGamepad
            case 'macros':
                return mdiCodeTags
            case 'miscellaneous':
                return mdiDipSwitch
            case 'led-effects':
                return mdiLedStrip
            case 'temperature':
                return mdiThermometerLines
            case 'miniconsole':
                return mdiConsoleLine
            case 'probe-progress':
                return mdiGrid
            case 'klippertools':
                return mdiToolboxOutline
            case 'nozzle-guard':
                return mdiShieldCheckOutline
            case 'start-flow':
                return mdiProgressClock
            case 'maintenance-tracker':
                return mdiWrenchClock
            case 'thermal-soak':
                return mdiThermometerLines
            case 'motion-wizard':
                return mdiTuneVariant
            case 'machine-settings':
                return mdiEngine
            case 'extruder-control':
                return mdiPrinter3dNozzle
            case 'spoolman':
                return mdiAdjust
            case 'mmu':
                return mdiMulticast
            case 'afc':
                return afcIconLogo

            default:
                return mdiInformation
        }
    }
}
