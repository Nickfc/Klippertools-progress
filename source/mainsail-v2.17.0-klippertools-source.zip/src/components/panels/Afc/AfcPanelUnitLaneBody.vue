<template>
    <div>
        <v-row class="my-3">
            <v-col class="pl-6 pr-0 pt-0 pb-0 d-flex flex-column">
                <v-tooltip top>
                    <template #activator="{ on, attr }">
                        <span class="d-flex align-center justify-center" v-bind="attr" v-on="on">
                            <afc-filament-reel
                                :percent="spoolPercent"
                                :color="spoolColor"
                                class="filamentSpool cursor-pointer"
                                @click-spool="onFilamentClick" />
                        </span>
                    </template>
                    <span>
                        #{{ spoolId }} | {{ spoolVendor }}
                        <br />
                        {{ spoolFilamentName }}
                    </span>
                </v-tooltip>
                <spoolman-change-spool-dialog v-if="afcExistsSpoolman" v-model="showSpoolmanDialog" :afc-lane="name" />
                <afc-unit-lane-filament-dialog v-model="showFilamentDialog" :name="name" />
            </v-col>
            <v-col class="pr-6 pl-2 pt-0 pb-0 d-flex flex-column justify-space-between align-end">
                <v-btn v-if="afcShowLaneInfinite" x-small @click="showInfintiyDialog = true">
                    <v-icon v-if="runoutLane === 'NONE'" color="error" small>{{ afcIconInfintiy }}</v-icon>
                    <template v-else>{{ runoutLane }}</template>
                </v-btn>
                <afc-unit-lane-infinite-dialog v-model="showInfintiyDialog" :name="name" />
                <span class="font-weight-bold">{{ spoolMaterial }}</span>
                <span class="text--disabled">{{ spoolRemainingWeightOutput }}</span>
                <v-tooltip v-if="hasTd" top>
                    <template #activator="{ on, attr }">
                        <span class="d-flex align-center justify-center text--disabled" v-bind="attr" v-on="on">
                            TD: {{ tdValue }}
                        </span>
                    </template>
                    <span>{{ $t('Panels.AfcPanel.Color') }}: #{{ tdColor }}</span>
                </v-tooltip>
            </v-col>
        </v-row>
        <v-row v-if="afcShowFilamentName" class="mb-0 mt-n3">
            <v-col class="px-6 pt-1">
                <div class="position-relative pb-4">
                    <span class="position-absolute text-truncate text-truncate-element text-center">
                        {{ spoolFilamentName }}
                    </span>
                </div>
            </v-col>
        </v-row>
    </div>
</template>
<script lang="ts">
import { Component, Mixins, Prop } from 'vue-property-decorator'
import BaseMixin from '@/components/mixins/base'
import AfcMixin from '@/components/mixins/afc'
import { ServerSpoolmanStateSpool } from '@/store/server/spoolman/types'
import { afcIconInfintiy } from '@/plugins/afcIcons'
import AfcUnitLaneInfiniteDialog from '@/components/dialogs/AfcUnitLaneInfiniteDialog.vue'
import AfcUnitLaneFilamentDialog from '@/components/dialogs/AfcUnitLaneFilamentDialog.vue'

@Component({
    components: {
        AfcUnitLaneFilamentDialog,
        AfcUnitLaneInfiniteDialog,
    },
})
export default class AfcPanelUnitLaneBody extends Mixins(BaseMixin, AfcMixin) {
    afcIconInfintiy = afcIconInfintiy

    @Prop({ type: String, required: true }) readonly name!: string

    showInfintiyDialog = false
    showSpoolmanDialog = false
    showFilamentDialog = false

    get lane() {
        return this.getAfcLaneObject(this.name)
    }

    get runoutLane() {
        return this.lane.runout_lane ?? 'NONE'
    }

    get spoolId(): number {
        return Number(this.lane.spool_id || '0')
    }

    get spool(): ServerSpoolmanStateSpool | null {
        if (this.spoolId === 0) return null

        const spools = this.$store.state.server.spoolman?.spools || []

        return spools.find((spool: ServerSpoolmanStateSpool) => spool.id === this.spoolId) || null
    }

    get spoolColor() {
        if (this.hasTd && this.showTd1Color) return `#${this.tdColor}`

        return this.lane.color || '#000000'
    }

    get spoolRemainingWeight() {
        return Math.round(this.lane.weight ?? 0)
    }

    get spoolRemainingWeightOutput() {
        return `${this.spoolRemainingWeight} g`
    }

    get spoolFullWeight() {
        return this.spool?.filament?.weight ?? 1000
    }

    get spoolPercent() {
        if (this.spoolFullWeight === 0) return 100

        return Math.round((this.spoolRemainingWeight / this.spoolFullWeight) * 100)
    }

    get spoolMaterial() {
        return this.lane.material || '--'
    }

    get spoolVendor() {
        return this.spool?.filament?.vendor?.name ?? 'Unknown'
    }

    get spoolFilamentName() {
        return this.spool?.filament?.name ?? 'Unknown'
    }

    get showTd1Color(): boolean {
        return this.$store.state.gui.view.afc?.showTd1Color ?? true
    }

    get hasTd() {
        return (this.lane?.td1_td || null) !== null
    }

    get tdValue() {
        return this.lane?.td1_td || '--'
    }

    get tdColor() {
        return this.lane?.td1_color || '------'
    }

    onFilamentClick() {
        if (this.afcExistsSpoolman) {
            this.showSpoolmanDialog = true
            return
        }

        this.showFilamentDialog = true
    }
}
</script>

<style scoped>
.filamentSpool {
    max-width: 38px;
}

.text-truncate-element {
    left: 0;
    right: 0;
}
</style>
