import{S as r}from"./Viewer-M3n0FsuH.js";const e="kernelBlurVaryingDeclaration",a="varying sampleCoord{X}: vec2f;";r.IncludesShadersStoreWGSL[e]=a;
