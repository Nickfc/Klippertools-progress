import{S as r}from"./Viewer-BX6OAHVX.js";const e="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";r.IncludesShadersStore[e]=a;
